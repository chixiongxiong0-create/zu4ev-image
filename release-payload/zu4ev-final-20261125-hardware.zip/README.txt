ZU4EV frozen hardware baseline 2026-11-25.
Extract beside the source checkout, preserving build/dpc paths.
Published source commit 83ba2627fa73e4b6b8f0a58f88e10e751f42161b has the exact Git tree of local build commit b84b697027ea0b1cf814fbfe643c63e0b0a81b4d.
manifest.json is the original full local build record. The archive omits the routed DCP and generated caches. SHA256SUMS covers files included here.
Vivado 2025.1. See FINAL_BASELINE.md for verification scope and remaining warnings. Board validation pending. No BOOT.BIN/QSPI image is included.
